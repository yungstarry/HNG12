select (SUM(clicks) * 100.0 / SUM(impressions)) as overallctr
from campaigndata;

