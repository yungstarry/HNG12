select campaign_id, company, roi
from campaigndata
order by roi desc
limit 1;
